aws-graphql-example
--------------------
GraphQL Application To Query Crypto coin market data, Hosted on AWS Lambda
